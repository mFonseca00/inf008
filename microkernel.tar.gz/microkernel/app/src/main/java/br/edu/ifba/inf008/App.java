package br.edu.ifba.inf008;

import br.edu.ifba.inf008.shell.Core;

/**
 * Hello world!
 */
public class App {
    public static void main(String[] args) {
        Core.init();
    }
}
