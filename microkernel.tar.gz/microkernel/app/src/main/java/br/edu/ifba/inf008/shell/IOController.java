package br.edu.ifba.inf008.shell;

import br.edu.ifba.inf008.interfaces.IIOController;

public class IOController implements IIOController
{
}
