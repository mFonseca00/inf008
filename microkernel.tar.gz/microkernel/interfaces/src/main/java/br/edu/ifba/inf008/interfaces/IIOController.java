package br.edu.ifba.inf008.interfaces;

public interface IIOController
{
}
