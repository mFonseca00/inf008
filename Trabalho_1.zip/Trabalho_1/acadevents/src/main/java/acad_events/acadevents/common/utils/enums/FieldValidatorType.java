package acad_events.acadevents.common.utils.enums;

public enum FieldValidatorType {
    CPF,
    EMAIL,
    PHONE,
    NOT_BLANK,
    POSITIVE_INT,
    DATE
}