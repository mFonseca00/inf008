package acad_events.acadevents.ui.functionalities.enums;

public enum InputResult {
    SUCCESS,
    CANCELLED,
    INVALID
}

