package acad_events.acadevents.common.utils.interfaces;

public interface I_EnumOptionList {
    int getValue();
    String getDescription();
}
